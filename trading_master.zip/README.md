# Taiwan Quantitative Trading Platform

A complete local AI quantitative trading platform for Taiwan (TWSE) stocks.
Covers research, backtesting, stock selection, and report generation.

## KPI Targets

| KPI | Target |
|-----|--------|
| Sharpe Ratio | > 1.5 |
| Max Drawdown | < 20% |
| Profit Factor | > 1.5 |

---

## Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Set your FinMind API token

Either edit `config.py`:
```python
FINMIND_TOKEN = "your_token_here"
```

Or set the environment variable:
```bash
# Windows
set FINMIND_TOKEN=your_token_here

# Linux/macOS
export FINMIND_TOKEN=your_token_here
```

Get a free token at: https://finmindtrade.com/

### 3. Download data

```bash
python main.py download
```

This downloads ~5 years of daily OHLCV for the top 200 Taiwan stocks.

### 4. Compute features

```bash
python main.py features
```

### 5. Train the ML model

```bash
python main.py train
```

### 6. Run a backtest

```bash
# Momentum strategy
python main.py backtest --strategy momentum

# Mean reversion
python main.py backtest --strategy mean_reversion

# Breakout
python main.py backtest --strategy breakout

# Walk-forward validation
python main.py backtest --strategy momentum --walk-forward
```

### 7. Run the daily pipeline

```bash
python main.py pipeline
```

### 8. Launch the dashboard

```bash
python main.py ui
# or directly:
streamlit run ui/dashboard.py
```

---

## Project Structure

```
trading_master/
├── config.py               # All configuration parameters
├── main.py                 # CLI entry point
├── requirements.txt
├── data/
│   ├── downloader.py       # FinMind API data download
│   ├── database.py         # SQLite read/write operations
│   └── updater.py          # Daily incremental update
├── features/
│   ├── indicators.py       # RSI, MACD, MA, Volume Spike, Bollinger Bands
│   ├── volatility.py       # ATR, historical volatility, Parkinson vol
│   ├── momentum.py         # N-day returns, rate of change, momentum score
│   └── regime.py           # Bull/Bear/Sideways + volatility regime
├── models/
│   ├── lgbm_model.py       # LightGBM regressor + classifier
│   ├── xgb_model.py        # XGBoost regressor + classifier
│   ├── ensemble.py         # Weighted ensemble
│   └── trainer.py          # Training pipeline + walk-forward CV
├── strategies/
│   ├── base.py             # Abstract base strategy
│   ├── momentum.py         # Top-N composite momentum
│   ├── mean_reversion.py   # RSI + Bollinger Band oversold
│   ├── breakout.py         # 20-day high breakout with volume
│   └── selector.py         # Regime-based auto selector
├── risk/
│   ├── position_sizing.py  # Fixed-fractional + Kelly sizing
│   ├── stop_loss.py        # ATR stop-loss + partial take-profit
│   └── drawdown.py         # Portfolio drawdown monitor
├── backtest/
│   ├── engine.py           # Vectorized backtest engine
│   └── walk_forward.py     # Rolling train/test validation
├── pipeline/
│   └── daily.py            # Full daily orchestration
├── reports/
│   └── generator.py        # Text report generation
└── ui/
    └── dashboard.py        # Streamlit dashboard
```

---

## Strategies

### Momentum
- Ranks all stocks by composite score: `0.1×ret_1d + 0.2×ret_5d + 0.3×ret_20d + 0.4×predicted_return`
- Buys top 10 stocks with equal weight
- Rebalances weekly (every 5 trading days)

### Mean Reversion
- Entry: RSI(14) < 30 AND price < lower Bollinger Band
- Exit: RSI > 55 OR price > SMA20
- Maximum 15 positions simultaneously

### Breakout
- Entry: price breaks 20-day high AND volume > 1.5× 20-day average
- Stop-loss: 2 × ATR below entry
- Take-profit: 3 × ATR above entry
- Partial take-profit at 1.5 × ATR (close 50% of position)

### Auto Selector
| Market Regime | Vol Regime | Selected Strategy |
|---------------|------------|-------------------|
| Bull | Low | Momentum |
| Bull | High | Breakout |
| Bear | Any | Mean Reversion |
| Sideways | Any | Mean Reversion |

---

## Risk Management

- **Position sizing**: Fixed-fractional – risk 1.5% per trade
- **Max position**: 10% of portfolio per stock
- **Stop-loss**: ATR-based (2× ATR below entry)
- **Take-profit**: ATR-based (3× ATR above entry)
- **Drawdown halt**: Trading halts automatically at 20% portfolio drawdown

---

## Transaction Costs (Taiwan)

| Cost | Rate |
|------|------|
| Buy commission | 0.1425% |
| Sell commission | 0.1425% |
| Sell securities tax | 0.30% |
| Slippage (per trade) | 0.10% |

---

## ML Model

### Features (30+)
RSI(14), MACD (line/signal/hist), SMA(5/10/20/60), EMA(12/26), volume spike,
Bollinger Band width/position, ATR%, historical volatility (20d/60d), Parkinson vol,
1d/5d/20d returns, rate-of-change, momentum score, 52-week high ratio,
distance from 20d high/low, regime code.

### Targets
- **Regression**: 5-day forward return
- **Classification**: 1 if 5-day return > 0, else 0

### Architecture
LightGBM + XGBoost ensemble with equal weighting (or learned weights via `learn_weights()`).

---

## Configuration

All parameters are in `config.py`. Key settings:

```python
FINMIND_TOKEN   = ""          # Your FinMind API token
INITIAL_CAPITAL = 1_000_000   # NTD 1 million
RISK_PER_TRADE  = 0.015       # 1.5% risk per trade
MAX_POSITION_SIZE = 0.10      # 10% cap per position
MAX_DRAWDOWN_HALT = 0.20      # Halt at 20% drawdown
FORWARD_RETURN_DAYS = 5       # Prediction horizon
```

---

## Data Source

All price data comes from [FinMind](https://finmindtrade.com/) via the official Python client.
Free-tier accounts have rate limits. A token is recommended for downloading the full universe.

Data is stored locally in SQLite (`trading_data.db`), so subsequent runs only fetch new data.
